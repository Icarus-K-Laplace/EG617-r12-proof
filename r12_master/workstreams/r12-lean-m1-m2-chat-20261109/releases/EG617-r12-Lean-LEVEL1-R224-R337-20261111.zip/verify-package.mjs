import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const rows=fs.readFileSync(path.join(root,'SHA256SUMS'),'utf8').trim().split('\n');
for(const row of rows){const m=/^([a-f0-9]{64})  (.+)$/.exec(row);if(!m||m[2].includes('..'))throw Error('Bad manifest row');const h=createHash('sha256').update(fs.readFileSync(path.join(root,m[2]))).digest('hex');if(h!==m[1])throw Error('SHA mismatch '+m[2]);}
console.log('PACKAGE_SHA256_PASS: '+rows.length+' files');
